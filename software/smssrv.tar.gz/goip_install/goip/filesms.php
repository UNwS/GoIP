<?php
define("OK", true);
require_once("session.php");
require_once("global.php");
//if($_SESSION['goip_permissions'] > 1 )
	//WriteErrMsg("<br><li>Permission denied!</li>");

require_once('filesms.htm');
?>
