<?php
define("OK", true);
require_once("session.php");
if($_SESSION['goip_permissions'] > 1)	
	die("需要admin权限！");	
require_once("global.php");
$action=$_GET['action'];
if($action=="del"){
	$ErrMsg="";
	$Id=$_GET['id'];
	print_r($_POST);
	if(empty($Id)){
		$num=$_POST['boxs'];
		for($i=0;$i<$num;$i++)
		{	
			if(!empty($_POST["Id$i"])){
				/*
				   if($_POST["Id$i"] == "1"){
				   $ErrMsg="<br><li>超级用户不能删除</li>";
				   WriteErrMsg($ErrMsg);
				   break;
				   }
				 */
				if($Id=="")
					$Id=$_POST["Id$i"];
				else
					$Id=$_POST["Id$i"].",$Id";
			}
		}
	}
	//WriteErrMsg("$Id");

	if(empty($Id))
		$ErrMsg ='<br><li>Please choose one</li>';
	if($ErrMsg!="")
		WriteErrMsg($ErrMsg);
	else{
		$query=$db->query("DELETE FROM recharge_record WHERE result!=100 and result!=101 and id IN ($Id)");

		WriteSuccessMsg("<br><li>删除成功</li>","?");

	}
}
else if($action=="delall"){
	$query=$db->query("DELETE FROM recharge_record where result!=100 and result!=101");                                        
	WriteSuccessMsg("<br><li>删除成功</li>","?");
                                                                                                                  
}

	
	$query=$db->query("SELECT count(*) AS count FROM recharge_record ");
	$row=$db->fetch_array($query);
	$count=$row['count'];
	$numofpage=ceil($count/$perpage);
	$totlepage=$numofpage;
	if(isset($_GET['page'])) {
		$page=$_GET['page'];
	} else {
		$page=1;
	}
	if($numofpage && $page>$numofpage) {
		$page=$numofpage;
	}
	if($page > 1) {
		$start_limit=($page - 1)*$perpage;
	} else{
		$start_limit=0;
		$page=1;
	}
	$fenye=showpage("?",$page,$count,$perpage,true,true,"编");
	$query=$db->query("SELECT * from recharge_record ORDER BY id DESC LIMIT $start_limit,$perpage");
	while($row=$db->fetch_array($query)) {
		$rsdb[]=$row;
	}
	$goipname=$rsdb[0][name];

?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link href="style.css" rel="stylesheet" type="text/css">
<title>Goip Record</title>
<script language="javascript">
function unselectall()
	{
	    if(document.myform.chkAll.checked){
		document.myform.chkAll.checked = document.myform.chkAll.checked&0;
	    } 	
	}

function CheckAll(form)
	{
		var trck;
		var e;
		for (var i=0;i<form.elements.length;i++)
	    {
		    e = form.elements[i];
		    if (e.type == 'checkbox' && e.id != "chkAll" && e.disabled==false){
				e.checked = form.chkAll.checked;
		 		do {e=e.parentNode} while (e.tagName!="TR") 
		 		if(form.chkAll.checked)
		 			e.className = 'even marked';
		 		else
		 			e.className = 'even';
			}
	    }
		//form.chkAll.classname = 'even';
	}

function mouseover(obj) {
                obj.className += ' hover';
				//alert(obj.className);
            	
			}

function mouseout(obj) {
            	obj.className = obj.className.replace( ' hover', '' );
				//alert(obj.className);
			}

function trclick(obj) {
		//alert("ddddd");
        var checkbox = obj.getElementsByTagName( 'input' )[0];
        //if ( checkbox && checkbox.type == 'checkbox' ) 
        checkbox.checked ^= 1;
		if(checkbox.checked)
			obj.className = 'even marked';
		else obj.className = 'even';
//		var ckpage=document.modifyform.elements['chkAll'+num];
	    if(document.myform.chkAll.checked){
		document.myform.chkAll.checked = document.myform.chkAll.checked&0;
	    } 	
		

		}

</script>
</head>
<body leftmargin="2" topmargin="0" marginwIdth="0" marginheight="0">
<table wIdth="100%" border="0" align="center" cellpadding="2" cellspacing="1" class="border">
  <tr class="topbg"> 
    <td height="22" colspan="2" align="center"><strong>Goip充值记录</strong></td>
  </tr>
  <tr class="tdbg"> 
<td wIdth="120" height="30"><strong>GoIP充值记录:</strong></td>
    <td height="30"><a href="re_record.php" target=main>参数管理</a></td>
  </tr>
</table>
<table width="100%" height="25"  border="0" cellpadding="0" cellspacing="0">
  <tr class="topbg">
    <td width="8%">&nbsp;</td>
    <td width="92%" height="25"><strong>当前位置：充值记录</strong></td>
  </tr>
</table>
<form action="re_record.php?action=del" method=post name=myform onSubmit="return confirm('确认删除?')">
<table wIdth="100%"  border="0" cellspacing="2" cellpadding="2">
	<tr class=title>
		<td wIdth="35" align=center height="25"><b>选择</b></td>
		<td align="center"><b>充值时间</b></td>
		<td align="center"><b>被充值号码</b></td>
		<td align="center"><b>被充值线路</b></td>
		<td align="center"><b>充值线路</b></td>
		<td align="center"><b>充值卡ICCID</b></td>
		<td align="center"><b>充值结果</b></td>
		<td wIdth="80" align=center><b>操作</b></td>
	</tr>
<!--
<?php 
$j=0;
foreach($rsdb as $rs) {
print <<<EOT
-->
	<tr class="even" onMouseOver="mouseover(this)" onMouseOut="mouseout(this)" onMouseDown="trclick(this)">
		<td align=center wIdth="35"><input name="Id{$j}" type='checkbox' onClick="return false" value="{$rs['id']}"></td>
		<td align="center">{$rs['date']}</td>
		<td align="center">{$rs['num']}</td>
		<td align="center">{$rs['be_name']}</td>
		<td align="center">{$rs['re_name']}</td>
		<td align="center">{$rs['re_sim_iccid']}</td>
		<td align="center">{$rs['result']}</td>
				
		<td align=center wIdth="80"><a href="re_record.php?id={$rs['id']}&action=del" onClick="return confirm('确认删除?')">删除</a></td>
    </tr>

<!--
EOT;
$j++;
}
print <<<EOT
-->
</table>
<input type="hIdden" name="boxs" value="{$j}">
<table wIdth="100%"  border="0" cellspacing="2" cellpadding="2">


					<tr>
						<td height="30" ><input name="chkAll" type="checkbox" Id="chkAll" onclick=CheckAll(this.form) value="checkbox"> 
					  选择当前页面<input name="submit" type='submit' value='删除所选'><input name="button" type='button' value='删除全部' onClick="if(confirm('确认删除数据库中的所有收到的短信?')) window.location='?action=delall'"></td>
					</tr>
					<tr>
						<td  align=center>{$fenye}</td>
					</tr>
</table>
<!--
EOT;
?>
-->
</form>

					  </td> 
					</tr>
</table>
				
</body>
</html>
