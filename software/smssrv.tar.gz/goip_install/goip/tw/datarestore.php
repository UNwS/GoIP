<?php 
if(!isset($_COOKIE['username'])) {
	require_once ('login.php');
	exit;
}

if($_COOKIE['permissions'] > 1)	
	die("need admin permissions!");	
ignore_user_abort(true);
set_time_limit(0);
ini_set("memory_limit", "200M");
ini_set("upload_max_filesize", "100M");
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>數據導入</title>
<meta name="Author" content="Gaby_chen">
<link href="../style.css" rel="stylesheet" type="text/css">
</head>
<body leftmargin="2" topmargin="0" marginwIdth="0" marginheight="0">
<table wIdth="100%" border="0" align="center" cellpadding="2" cellspacing="1" class="border">
  <tr class="topbg"> 
    <td height="22" colspan="2" align="center"><strong>數據管理</strong></td>
  </tr>
  <tr class="tdbg"> 
    <td wIdth="100" height="30"><strong>管理導航:</strong></td>
    <td height="30"><a href="databackup.php"  target=main>數據備份</a> | <a href="datarestore.php" target=main>數據導入</a></td>
  </tr>
</table>
<?php
define('OK', true);
require_once('../inc/conn.inc.php');

global $mysqlhost, $mysqluser, $mysqlpwd, $mysqldb;
$mysqlhost=$dbhost; //host name
$mysqluser=$dbuser;              //login name
$mysqlpwd=$dbpw;              //password
$mysqldb=$dbname;        //name of database


require_once("datamydb.php");
$d=new datadb($mysqlhost,$mysqluser,$mysqlpwd,$mysqldb);
/******界面*/
if(!$_POST['act']&&!$_SESSION['goip_data_file']){
/**********************/
?>

<br> 
<table wIdth="100%" border="0" align="center" cellpadding="0" cellspacing="1" class="border">
  <tr class="title">
    <td height="22"><strong> 提示： </strong></td>
  </tr>
  <tr class="tdbg" onmouseout="this.style.backgroundColor=''" onmouseover="this.style.backgroundColor='#BFDFFF'">
    <td valign="middle"><ul>
        <li>本功能在恢複備份數據的同時，將全部覆蓋原有數據，請確定是否需要恢複，以免造成數據損失
        <li>數據恢複功能只能恢複由本系統導出的數據文件，其他軟件導出格式可能無法識別
        <li>從本地恢複數據需要服務器支持文件上傳並保證數據尺寸小于允許上傳的上限，否則只能使用從服務器恢複</li>
		<li>如果您使用了分卷備份，只需手工導入文件卷1，其他數據文件會由系統自動導入</li>
   	 </ul>
	</td>
  </tr>
</table>
<br>
<form action="" method="post" enctype="multipart/form-data" name="datarestore.php">
<table wIdth="100%" border="0" align="center" cellpadding="0" cellspacing="1" class="border">
  <tr class="title"> 
    <td height="22" colspan="2" align="center"><strong>數據恢複</strong></td>
  </tr>
  <tr class="tdbg" onmouseout="this.style.backgroundColor=''" onmouseover="this.style.backgroundColor='#BFDFFF'"> 
    <td colspan="2">備份方式</td>
  </tr>
  <tr class="tdbg" onmouseout="this.style.backgroundColor=''" onmouseover="this.style.backgroundColor='#BFDFFF'"> 
    <td><input type="radio" name="restorefrom" value="server" checked>
從服務器文件恢複</td>
  <td><select name="serverfile">
    <option value="">-請選擇-</option>
    <?php
$handle=opendir('../backup');
while ($file = readdir($handle)) {
    if(eregi("^[0-9]{8,8}([0-9a-z_]+)(\.sql)$",$file)) echo "<option value='$file'>$file</option>";}
closedir($handle); 
?>
  </select></td>
  </tr>
   <tr class="tdbg" onmouseout="this.style.backgroundColor=''" onmouseover="this.style.backgroundColor='#BFDFFF'"> 
     <td><input type="radio" name="restorefrom" value="localpc">
從本地文件恢複</td>
     <td><input type="hidden" name="MAX_FILE_SIZE" value="1500000">
      <input type="file" name="myfile"></td>
  </tr>
   <tr align="center" class="tdbg" onmouseover="this.style.backgroundColor='#BFDFFF'" onmouseout="this.style.backgroundColor=''"> 
    <td colspan="2"><input type="submit" name="act" value="恢複"></td>
  </tr>
</table> 
</form>

<?php /**************************界面結束*/}/*************************************/
/****************************主程序*/if($_POST['act']=="恢複"){/**************/
/***************服務器恢複*/if($_POST['restorefrom']=="server"){/**************/
if(!$_POST['serverfile'])
	{$msgs[]="您選擇從服務器文件恢複備份，但沒有指定備份文件";
	 show_msg($msgs); pageend();	}
if(!eregi("_v[0-9]+",$_POST['serverfile']))
	{$filename="../backup/".$_POST['serverfile'];
	if(import($filename)) $msgs[]="備份文件".$_POST['serverfile']."成功導入數據庫";
	else $msgs[]="備份文件".$_POST['serverfile']."導入失敗";
	show_msg($msgs); pageend();		
	}
else
	{
	$filename="../backup/".$_POST['serverfile'];
	if(import($filename)) $msgs[]="備份文件".$_POST['serverfile']."成功導入數據庫";
	else {$msgs[]="備份文件".$_POST['serverfile']."導入失敗";show_msg($msgs);pageend();}
	$voltmp=explode("_v",$_POST['serverfile']);
	$volname=$voltmp[0];
	$volnum=explode(".sq",$voltmp[1]);
	$volnum=intval($volnum[0])+1;
	$tmpfile=$volname."_v".$volnum.".sql";
	if(file_exists("../backup/".$tmpfile))
		{
		$msgs[]="程序將在3秒鍾後自動開始導入此分卷備份的下一部份：文件".$tmpfile."，請勿手動中止程序的運行，以免數據庫結構受損";
		$_SESSION['goip_data_file']=$tmpfile;
		show_msg($msgs);
		sleep(3);
		echo "<script language='javascript'>"; 
		echo "location='restore.php';"; 
		echo "</script>"; 
		}
	else
		{
		$msgs[]="此分卷備份全部導入成功";
		show_msg($msgs);
		}
	}
/**************服務器恢複結束*/}/********************************************/
/*****************本地恢複*/if($_POST['restorefrom']=="localpc"){/**************/
	switch ($_FILES['myfile']['error'])
	{
	case 1:
	case 2:
	$msgs[]="您上傳的文件大于服務器限定值，上傳未成功";
	break;
	case 3:
	$msgs[]="未能從本地完整上傳備份文件";
	break;
	case 4:
	$msgs[]="從本地上傳備份文件失敗!";
	break;
    case 0:
	break;
	}
	if($msgs){show_msg($msgs);pageend();}
$fname=date("Ymd",time())."_.sql";
if (is_uploaded_file($_FILES['myfile']['tmp_name'])) {

$attach_name=$_FILES["myfile"]['name'];
	$attach_size=$_FILES["myfile"]['size'];
	$attachment=$_FILES["myfile"]['tmp_name'];
	$db_uploadmaxsize='20480000';
	$db_uploadfiletype='sql';
	$attachdir="../backup/";
	if(!$attachment || $attachment== 'none'){
		showerror('upload_content_error');
	} elseif(function_exists('is_uploaded_file') && !is_uploaded_file($attachment)){
		showerror('upload_content_error');
	} elseif(!($attachment && $attachment['error']!=4)){
		showerror('upload_content_error');
	}
	if ($attach_size>$db_uploadmaxsize){
		showerror("upload_size_error");
	}
	
	$available_type = explode(' ',trim($db_uploadfiletype));
	$attach_ext = substr(strrchr($attach_name,'.'),1);
	$attach_ext=strtolower($attach_ext);
	if($attach_ext == 'php' || empty($attach_ext) || !@in_array($attach_ext,$available_type)){
		showerror('upload_type_error');
	}
	$randvar=num_rand('15');
	$uploadname=$randvar.'.'.$attach_ext;

	if(!is_dir($attachdir)) {
			@mkdir($attachdir);
			@chmod($attachdir,0777);
		}
		
	$source=$attachdir.'/'.$fname;
	if(function_exists("move_uploaded_file") && @move_uploaded_file($attachment, $source)){
		chmod($source,0777);
		$attach_saved = 1;
	}elseif(@copy($attachment, $source)){
		chmod($source,0777);
		$attach_saved = 1;
	}elseif(is_readable($attachment) && $attcontent=readover($attachment)){
		$attach_saved = 1;
		writeover($source,$attcontent);
		chmod($source,0777);
	}

	
//echo "../backup/".$fname;
   // copy($_FILES['myfile']['tmp_name'], "../backup/".$fname);
   }

if (file_exists("../backup/".$fname)) 
	{
	$msgs[]="本地備份文件上傳成功";
	if(import("../backup/".$fname)) {$msgs[]="本地備份文件成功導入數據庫"; unlink("../backup/".$fname);}
	else $msgs[]="本地備份文件導入數據庫失敗";
	}
else ($msgs[]="從本地上傳備份文件失敗");
show_msg($msgs);
/****本地恢複結束*****/}/****************************************************/
/****************************主程序結束*/}/**********************************/
/*************************剩余分卷備份恢複**********************************/
if(!$_POST['act']&&$_SESSION['goip_data_file'])
{
	$filename="../backup/".$_SESSION['goip_data_file'];
	if(import($filename)) $msgs[]="備份文件".$_SESSION['goip_data_file']."成功導入數據庫";
	else {$msgs[]="備份文件".$_SESSION['goip_data_file']."導入失敗";show_msg($msgs);pageend();}
	$voltmp=explode("_v",$_SESSION['goip_data_file']);
	$volname=$voltmp[0];
	$volnum=explode(".sq",$voltmp[1]);
	$volnum=intval($volnum[0])+1;
	$tmpfile=$volname."_v".$volnum.".sql";
	if(file_exists("../backup/".$tmpfile))
		{
		$msgs[]="程序將在3秒鍾後自動開始導入此分卷備份的下一部份：文件".$tmpfile."，請勿手動中止程序的運行，以免數據庫結構受損";
		$_SESSION['goip_data_file']=$tmpfile;
		show_msg($msgs);
		sleep(3);
		echo "<script language='javascript'>"; 
		echo "location='restore.php';"; 
		echo "</script>"; 
		}
	else
		{
		$msgs[]="此分卷備份全部導入成功";
		unset($_SESSION['goip_data_file']);
		show_msg($msgs);
		}
}
/**********************剩余分卷備份恢複結束*******************************/
function import($fname)
{global $d;
$sqls=file($fname);
foreach($sqls as $sql)
	{
	str_replace("\r","",$sql);
	str_replace("\n","",$sql);
	if(!$d->query(trim($sql))) return false;
	}
return true;
}
function show_msg($msgs)
{
	$strErr="<html><head><title>Error Information</title><meta http-equiv='Content-Type' content='text/html; charset=utf-8'>" ;
	$strErr=$strErr."<link href='../style.css' rel='stylesheet' type='text/css'></head><body>" ;
	$strErr=$strErr."<br><br><table cellpadding=2 cellspacing=1 border=0 wIdth=400 class='border' align=center>"; 
	$strErr=$strErr."  <tr align='center'><td height='22' class='title'><strong>信息</strong></td></tr>" ;
	$strErr=$strErr."  <tr><td height='100' class='tdbg' valign='top'><b>提示:</b><br><ul>";
	while (list($k,$v)=each($msgs))
	$strErr=$strErr."<li>".$v."</li>";
	$strErr=$strErr."</ul></td></tr>" ;
	$strErr=$strErr."  <tr align='center'><td class='tdbg'><a href=javascript:history.back();>&lt;&lt; 返回</a></td></tr>" ;
	$strErr=$strErr."</table>" ;
	$strErr=$strErr."</body></html>" ;
	echo $strErr;
	exit;
}


function pageend()
{
exit();
}

function showerror($msg){
	//@extract($GLOBALS, EXTR_SKIP);
	//require_once GetLang('msg');
	//$lang[$msg] && $msg=$lang[$msg];
	echo "<script>"
		."alert('$msg');"
		."history.back();"
		."window.returnValue = '';"
		."window.close();"
		."</script>";
	exit;
}

function num_rand($lenth){
	mt_srand((double)microtime() * 1000000);
	for($i=0;$i<$lenth;$i++){
		$randval.= mt_rand(0,9);
	}
	$randval=substr(md5($randval),mt_rand(0,32-$lenth),$lenth);
	return $randval;
}
?>

<br><br>
</body> 
</html> 
