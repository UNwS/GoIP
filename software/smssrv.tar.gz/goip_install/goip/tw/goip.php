<?php

define("OK", true);
if($_COOKIE['permissions'] > 1)	
	die("需要admin權限！");	
require_once("global.php");
//!defined('OK') && exit('ForbIdden');
//$UserName=$_COOKIE['adminname'];
function sendto_cron()
{
			global $goipcronport;
			if(!$goipcronport) $goipcronport=44444;
			$flag=0;
			/* 此是最新計劃， 喚醒服務進程*/
			if (($socket = socket_create(AF_INET, SOCK_DGRAM, SOL_UDP)) <= 0) {
				echo "socket_create() failed: reason: " . socket_strerror($socket) . "\n";
				exit;
			}
			if (socket_sendto($socket,"goip", 4, 0, "127.0.0.1", $goipcronport)===false)
				echo ("sendto error");
			for($i=0;$i<3;$i++){
				$read=array($socket);
				$err=socket_select($read, $write = NULL, $except = NULL, 5);
				if($err>0){		
					if(($n=@socket_recvfrom($socket,$buf,1024,0,$ip,$port))==false){
						//echo("recvform error".socket_strerror($ret)."<br>");
						continue;
					}
					else{
						if($buf="OK"){
							$flag=1;
							break;
						}
					}
				}
				
			}
		if($flag)
			echo "已更新";
		else 
			echo "已更新,但goipcron進程未響應，請檢查該進程";
}

if(isset($_GET['action'])) {
	//if($_GET['action'] != "modifyself" && $_GET['action'] != "savemodifyself" && $_COOKIE['adminname']!="admin" )
		//WriteErrMsg("<br><li>需要admin權限!</li>");
	$action=$_GET['action'];
	
	if($action=="del")
	{
					$ErrMsg="";
					$Id=$_GET['id'];
					//if(($Id=$_GET['id']) == "1")
						//$ErrMsg="<br><li>超級用戶不能刪除</li>";
					
					if(empty($Id)){
						$num=$_POST['boxs'];
						for($i=0;$i<$num;$i++)
						{	
							if(!empty($_POST["Id$i"])){
							/*
							  if($_POST["Id$i"] == "1"){
							  		$ErrMsg="<br><li>超級用戶不能刪除</li>";
									WriteErrMsg($ErrMsg);
									break;
							  }
							  */
								if($Id=="")
									$Id=$_POST["Id$i"];
								else
									$Id=$_POST["Id$i"].",$Id";
							}
						}
					}
					//WriteErrMsg($num."$Id");
					
					if(empty($Id))
						$ErrMsg ='<br><li>Please choose one</li>';
					if($ErrMsg!="")
						WriteErrMsg($ErrMsg);
					else{
						$query=$db->query("DELETE FROM goip WHERE id IN ($Id)");
						sendto_cron();
						WriteSuccessMsg("<br><li>刪除goip設備成功</li>","goip.php");
						
					}
		//$id=$_GET['id'];
		//$query=$db->query("Delete  from ".$tablepre."admin WHERE Id=$id");
	}
	elseif($action=="add")
	{
		$query=$db->query("select id,prov from prov ");
		while($row=$db->fetch_array($query)) {
			$prsdb[]=$row;
		}		
	}
	elseif($action=="modify")
	{
		$id=$_GET['id'];
		$query=$db->query("select id,prov from prov ");
		while($row=$db->fetch_array($query)) {
			$prsdb[]=$row;
		}
		$rs=$db->fetch_array($db->query("SELECT * FROM goip where id=$id"));
		
		//if(!$s[0])
			//WriteErrMsg("<br><li>添加用戶需要admin權限</li>"."$row[1]");
	}
	elseif($action=="saveadd")
	{
					//WriteErrMsg("'$_POST['name']'");
					$name=$_POST['name'];
					$password=$_POST['Password'];
					$provider=$_POST['provider'];
					
					//$info=$_POST['info'];
					$ErrMsg="";
					if(empty($name))
						$ErrMsg ='<br><li>請輸入名稱</li>';
					if(empty($password))
						$ErrMsg ='<br><li>請輸入密碼</li>';
					$no_t=$db->fetch_array($db->query("select id from goip where name='".$name."'"));
					if($no_t[0])
						$ErrMsg	.='<br><li>已存在ID: '.$name.'</li>';
					if($ErrMsg!="")
						WriteErrMsg($ErrMsg);
					else{
					/*
						$query=$db->query("SELECT id FROM goip WHERE name='$username' ");
						$rs=$db->fetch_array($query);
						if(empty($rs[0])){$password=md5($password);
							$query=$db->query("INSERT INTO ".$tablepre."admin (UserName,Password,Info) VALUES ('$username','$password','$info')");
							WriteSuccessMsg("<br><li>Add administrator success</li>","{$URL}?job=user");
						}
						else{
							$ErrMsg=$ErrMsg."<br><li>Administrator [$username] have existed</li>";
							WriteErrMsg($ErrMsg);
						}
					*/

							$query=$db->query("INSERT INTO goip (name,password,provider) VALUES ('$name','$password','$provider')");
							sendto_cron(); 
							WriteSuccessMsg("<br><li>添加goip設備成功</li>","goip.php");				
					}
	}
	elseif($action=="savemodify")
	{
					$password=$_POST['Password'];
					$Id=$_POST['Id'];
					$name=$_POST['name'];
					$ErrMsg="";
					/*
					if(empty($password))
						$ErrMsg ='<br><li>Your password should not be empty</li>';
					*/
					$no_t=$db->fetch_array($db->query("select id from goip where name='".$name."' and id != $Id" ));
					if($no_t[0])
						$ErrMsg	.='<br><li>已存在ID: '.$name.'</li>';					
					if($ErrMsg!="")
						WriteErrMsg($ErrMsg);
					else{
						if($password)
							$pas=",password='$password'";
						$query=$db->query("UPDATE goip SET name='$name',provider='".$_POST['provider']."'".$pas."  WHERE id='$Id'");
						sendto_cron(); 
						WriteSuccessMsg("<br><li>Modify administrator success</li>","goip.php");
					}
	}
        elseif($action=="search"){
                $key=$_POST['key'];
                $type=$_POST['type'];
                switch($type){
                        case 1:
                                $query=$db->query("SELECT goip.*,prov.prov, prov.id as provid FROM goip,prov where goip.provider=prov.id and goip.name='$key' ORDER BY goip.id DESC");
                                $typename="ID";
                                break;
                        default:
                                $typename="無效項";
                }
                $searchcount=0;
                while($row=$db->fetch_array($query)) {
                        if($row['alive'] == 1){
                                $row['alive']="已註冊";
                        }
                        elseif($row['alive'] == 0){
                                $row['alive']="未註冊";
                                $row['sendsms']="onClick=\"alert('GoIP logout!');return false;\"";
                        }
                        $searchcount++;
                        $rsdb[]=$row;
                }
                $maininfo="搜索項：$typename, 查詢關鍵字：$key, 結果共{$searchcount}項.";
        }
	else $action="main";
	
}
else $action="main";

//if($_COOKIE['adminname']=="admin")	
if($action=="main")
{
	$maininfo="當前位置：goip參數設置";
	$query=$db->query("SELECT count(*) AS count FROM goip");
	$row=$db->fetch_array($query);
	$count=$row['count'];
	$numofpage=ceil($count/$perpage);
	$totlepage=$numofpage;
	if(isset($_GET['page'])) {
		$page=$_GET['page'];
	} else {
		$page=1;
	}
	if($numofpage && $page>$numofpage) {
		$page=$numofpage;
	}
	if($page > 1) {
		$start_limit=($page - 1)*$perpage;
	} else{
		$start_limit=0;
		$page=1;
	}
	$fenye=showpage("?",$page,$count,$perpage,true,true,"編");
	$query=$db->query("SELECT goip.*,prov.prov,prov.id as provid FROM goip,prov where goip.provider=prov.id ORDER BY goip.id DESC LIMIT $start_limit,$perpage");
	while($row=$db->fetch_array($query)) {
		if($row['alive'] == 1)
			$row['alive']="已注冊";
		elseif($row['alive'] == 0){
			$row['alive']="未注冊";
			$row['sendsms']="onClick=\"alert('GoIP logout!');return false;\"";
		}
		$rsdb[]=$row;
	}
}
	require_once ('goip.htm');

?>
