<?php
if(!isset($_COOKIE['username'])) {
	require_once ('login.php');
	exit;
}
define("OK", true);
require_once("global.php");

	if($_GET['type']=="all"){
		if($_COOKIE[userid]>1)
			die("沒有權限");
	}

if($_COOKIE[userid]<2)
	$otherh='<a href="sendinfo.php?type=all" target=main>所有人的發送</a>';
if($_GET['action']=='del') //删除
{

	$ErrMsg="";
	$Id=$_GET['id'];

	if(empty($Id)){
		$num=$_POST['boxs'];
		for($i=0;$i<$num;$i++)
		{	
			if(!empty($_POST["Id$i"])){
				if($Id=="")
					$Id=$_POST["Id$i"];
				else
					$Id=$_POST["Id$i"].",$Id";
			}
		}
	}
	//WriteErrMsg($num."$Id");

	if(empty($Id))
		$ErrMsg ='<br><li>Please choose one</li>';
	if($ErrMsg!="")
		WriteErrMsg($ErrMsg);
	else{
		$query=$db->query("DELETE FROM receive WHERE id IN ($Id)");
		WriteSuccessMsg("<br><li>刪除短信成功</li>","receive.php");

	}
}
elseif($_GET['action']== 'read') { //查看
	if(!$_GET['id'])
		exit;
	$db->query("update receive set status=1 where id=$_GET[id]");
	$row=$db->fetch_array($db->query("select * from receive where id=$_GET[id]"));
	require_once("receive_read.htm");
}
else { //列表
	if($_COOKIE['permissions']<2){

	}


        if(!$_REQUEST[goipname]) $goipname='goipname';
        else $goipname="'$_REQUEST[goipname]'";
        //echo "!$_POST[goipname] SELECT count(*) AS count FROM receive where goipname='$goipname'";
        $query=$db->query("SELECT count(*) AS count FROM receive where goipname=$goipname");
        $row=$db->fetch_array($query);
        $count=$row['count'];
        $numofpage=ceil($count/$perpage);
        $totlepage=$numofpage;
        if(isset($_GET['page'])) {
                $page=$_GET['page'];
        } else {
                $page=1;
        }
        if($numofpage && $page>$numofpage) {
                $page=$numofpage;
        }
        if($page > 1) {
                $start_limit=($page - 1)*$perpage;
        } else{
                $start_limit=0;
                $page=1;
        }
        $fenye=showpage("receive.php?goipname=$_REQUEST[goipname]&",$page,$count,$perpage,true,true,"编");

        //$db->query("update receive set status=1 ORDER BY time DESC LIMIT $start_limit,$perpage");
        $query=$db->query("SELECT * from receive where goipname=$goipname ORDER BY time DESC LIMIT $start_limit,$perpage");

	while($row=$db->fetch_array($query)){
		if($upid) $upid.=",".$row[id];
		else $upid=$row[id];
/*
		if($row[status]==0)
			$row[status]='<font color="#FF0000">未閱</font>';
		else 
			$row[status]='已閱';
*/
		$rsdb[]=$row;
		
	}
	if($upid) $db->query("update receive set status=1 where id in ($upid)");
	require_once("receive.htm");
}
//print_r($rsdb);
?>

