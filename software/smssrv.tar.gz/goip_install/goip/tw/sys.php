<?php
if(!isset($_COOKIE['username'])) {
	require_once ('login.php');
	exit;
}

if($_COOKIE['permissions'] > 1)	
	die("需要admin權限！");	
define("OK", true);
require_once("global.php");
require_once('../inc/conn.inc.php');


if($_GET['action'] != "save"){
/*
if ($username==''){
	$FoundErr=true;
	$ErrMsg= "<br><li>用戶名不能爲空!</li>";
}
if ($password==''){
	$FoundErr=true;
	$ErrMsg=$ErrMsg."<br><li>密碼不能爲空!</li>";
}
*/
  if($FoundErr!=true){
  	$query=$db->query("SET NAMES 'utf8'");
	$query=$db->query("SELECT * FROM system WHERE 1 ");
	$rs=$db->fetch_array($query);
	$sysname=$rs['sysname'];
	$maxword=$rs['maxword'];
	$lan=$rs['lan'];
/*
	if(empty($adminId)){
		$FoundErr=true;
		$ErrMsg=$ErrMsg."<br><li>用戶名或密碼錯誤!</li> $password";
	}
	else{

	}
*/
  }
}
else {
	$sysname=$_POST['sysname'];
	$maxword=$_POST['maxword'];
	$lan=$_POST['lan'];
	$query=$db->query("UPDATE system SET sysname='$sysname',lan=$lan where 1");
	WriteSuccessMsg("<br><li>保存成功</li>","sys.php");	
}
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link href="../style.css" rel="stylesheet" type="text/css">
<title>系統參數設置</title>
<script language="JavaScript" type="text/JavaScript">
function check()
{
  var dec_num=/^[0-9]+$/;
  if (document.myform.maxword.value=="" || !dec_num.test(document.myform.maxword.value))
  {
    alert("信息最大字數輸入錯誤!");
	document.myform.maxword.focus();
	return false;
  }
}
</script>
</head>
<body leftmargin="2" topmargin="0" marginwIdth="0" marginheight="0">
<table width="100%" height="25"  border="0" cellpadding="0" cellspacing="0">
  <tr class="topbg">
    <td width="8%">&nbsp;</td>
    <td width="92%" height="25"><strong>當前位置：系統參數設置</strong></td>
  </tr>
</table>
<form method="post" action="sys.php?action=save" name="myform" onSubmit="javascript:return check();">
  <br>
  <br>
  <table wIdth="300" border="0" align="center" cellpadding="2" cellspacing="1" class="border" >
    <tr class="title"> 
      <td height="22" colspan="2"> <div align="center"><strong>系統參數參數設定</strong></div></td>
    </tr>
    <tr> 
      <td wIdth="100" align="right" class="tdbg"><strong>系統名稱:</strong></td>
      <td class="tdbg"><input type="input" name="sysname" value="<?php echo $sysname ?>"></td>
    </tr>
    <tr> 
      <td wIdth="100" align="right" class="tdbg"><strong>默認語言:</strong></td>
      <td class="tdbg"><select name="lan">
	  						<option value="1" <?php if($lan==1) echo 'selected' ?>>簡體中文</option>
	  						<option value="2" <?php if($lan==2) echo 'selected' ?>>繁體中文</option>
							<option value="3" <?php if($lan==3) echo 'selected' ?>>英語</option>
						</select>
						</td>
    </tr>
<!--
    <tr> 
      <td wIdth="100" align="right" class="tdbg"><strong>信息最大字數:</strong></td>
      <td class="tdbg"><input type="input" name="maxword" value="<?php echo $maxword ?>"> </td>
    </tr>
-->	
    <tr> 
      <td height="40" colspan="2" align="center" class="tdbg"><input name="Action" type="hIdden" Id="Action" value="Modify"> 
        <input  type="submit" name="Submit" value="保 存" style="cursor:hand;"> 
 
        &nbsp;<input name="Cancel" type="button" Id="Cancel" value="取 消" onClick="window.location.href='sys.php'" style="cursor:hand;"></td>
    </tr>
  </table>
  </form>
					  </td> 
					</tr>
</table>
				
</body>
</html>

