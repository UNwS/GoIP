<?php
define("OK", true);
require_once('../inc/conn.inc.php');

$FoundErr=false;
$username=str_replace("'","",trim($_POST['username']));
$password=str_replace("'","",trim($_POST['password']));

if ($username==''){
	$FoundErr=true;
	$ErrMsg= "<br><li>用戶名不能爲空!</li>";
}
if ($password==''){
	$FoundErr=true;
	$ErrMsg=$ErrMsg."<br><li>密碼不能爲空!</li>";
}
if($FoundErr!=true){$password=md5($password);
	$query=$db->query("SELECT id,permissions FROM user WHERE username='$username' and password='$password' ");
	$rs=$db->fetch_array($query);
	$adminId=$rs[0];
	if(empty($adminId)){
		$FoundErr=true;
		$ErrMsg=$ErrMsg."<br><li>用戶名或密碼錯誤!</li>";
	}
	else{

		setcookie("username","$username",time()+3600);
		setcookie("userid","$adminId",time()+3600);
		setcookie("permissions", $rs['permissions'],time()+3600);
		switch($rs['permissions']){
			case 0:$s='系統管理員';break;
			case 1:$s='高級管理員';break;
			case 2:$s='群管理員';break;
			case 3:$s='組管理員';break;
		}
		setcookie("jibie", $s);
		Header("Location: index.php"); 
	}
}

if($FoundErr==true){
	$strErr="<html><head><title>Error Information</title><meta http-equiv='Content-Type' content='text/html; charset=utf-8'>" ;
	$strErr=$strErr."<link href='../style.css' rel='stylesheet' type='text/css'></head><body>" ;
	$strErr=$strErr."<table cellpadding=2 cellspacing=1 border=0 wIdth=400 class='border' align=center>"; 
	$strErr=$strErr."  <tr align='center'><td height='22' class='title'><strong>錯誤信息</strong></td></tr>" ;
	$strErr=$strErr."  <tr><td height='100' class='tdbg' valign='top'><b>原因:</b><br>$ErrMsg</td></tr>" ;
	$strErr=$strErr."  <tr align='center'><td class='tdbg'><a href=javascript:history.back();>&lt;&lt; 返回</a></td></tr>" ;
	$strErr=$strErr."</table>" ;
	$strErr=$strErr."</body></html>" ;
	echo $strErr;
}

?>
