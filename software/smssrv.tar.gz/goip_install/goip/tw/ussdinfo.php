<?php
if(!isset($_COOKIE['username'])) {
        require_once ('login.php');
        exit;
}
define("OK", true);
require_once("global.php");

        if(!$_REQUEST[goipname]) $goipname='TERMID';
        else $goipname="'$_REQUEST[goipname]'";
        //echo "!$_POST[goipname] SELECT count(*) AS count FROM receive where goipname='$goipname'";
        $query=$db->query("SELECT count(*) AS count FROM USSD where TERMID=$goipname");
        $row=$db->fetch_array($query);
        $count=$row['count'];
        $numofpage=ceil($count/$perpage);
        $totlepage=$numofpage;
        if(isset($_GET['page'])) {
                $page=$_GET['page'];
        } else {
                $page=1;
        }
        if($numofpage && $page>$numofpage) {
                $page=$numofpage;
        }
        if($page > 1) {
                $start_limit=($page - 1)*$perpage;
        } else{
                $start_limit=0;
                $page=1;
        }
        $fenye=showpage("ussdinfo.php?goipname=$_REQUEST[goipname]&",$page,$count,$perpage,true,true,"编");

        $query=$db->query("SELECT * from USSD  where TERMID=$goipname ORDER BY INSERTTIME DESC LIMIT $start_limit,$perpage");
        while($row=$db->fetch_array($query)) {
                $rsdb[]=$row;
        }
//print_r($rsdb);
        //require_once template("ussdinfo");
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link href="../style.css" rel="stylesheet" type="text/css">
<title>USSD信息查詢</title>
<script language="javascript">
function mouseover(obj) {
                obj.className += ' hover';
                                //alert(obj.className);            
                        }
function mouseout(obj) {
                obj.className = obj.className.replace( ' hover', '' );
                                //alert(obj.className);
                        }
function trclick(obj) {
                //alert("ddddd");
        var checkbox = obj.getElementsByTagName( 'input' )[0];
        //if ( checkbox && checkbox.type == 'checkbox' ) ;
        checkbox.checked ^= 1;
                if(checkbox.checked)
                        obj.className = 'even marked';
                else obj.className = 'even';
//              var ckpage=document.modifyform.elements['chkAll'+num];
                }
</script>
</head>
<body leftmargin="2" topmargin="0" marginwIdth="0" marginheight="0">
<table wIdth="100%" border="0" align="center" cellpadding="2" cellspacing="1" class="border">
  <tr class="topbg"> 
    <td height="22" colspan="2" align="center"><strong>USSD信息</strong></td>
  </tr>
  <tr class="tdbg"> 
    <td wIdth="120" height="30"><strong>USSD信息導航</strong></td>
    <td height="30"><a href="ussd_ch.php" target=main>USSD發送</a></td>
  </tr>
</table>
<!--
<?php 

print <<<EOT
-->
  </tr>
</table>
<form action="ussdinfo.php" method="post">                                                                        
搜索GoIP<input type="text" name="goipname" value="$_REQUEST[goipname]" size=16>&nbsp;<input type="submit" value="搜索">         
</form> 
<table wIdth="100%"  border="0" cellspacing="2" cellpadding="2" nowrap=false>
        <tr class=title>
                <td align="center" width="120"><b>發送時間</b></td>
                <td align="center"><b>USSD命令</b></td>
                <td align="center"><b>USSD返回</b></td>
                <td align="center"><b>發送終端</b></td>
                <td align="center"><b>失敗信息</b></td>

        </tr>

<!-- 
EOT;
$j=0;
foreach($rsdb as $rs) {
$rs['msg']=htmlspecialchars($rs['msg']);
$rs['msg']=str_replace("\n", "<br>", $rs['msg']);
print <<<EOT
-->
        <tr class="even" onMouseOver="mouseover(this)" onMouseOut="mouseout(this)">
                <td align="center">{$rs['INSERTTIME']}</td>
                <td  width="10%" style="word-break : break-all; ">{$rs['USSD_MSG']}</td>
                <td  width="50%" style="word-break : break-all; ">{$rs['USSD_RETURN']}</td>
                <td align="center">{$rs['TERMID']}</td>
                <td align="center">{$rs['ERROR_MSG']}</td>


    </tr>

<!--
EOT;
$j++;
}
print <<<EOT
-->
</table>
                                        <tr>
                                                <td  align=center>{$fenye}</td>
                                        </tr>
<!--
EOT;
?>
-->

</body>
</html>
