<?php
define("OK", true);
if($_COOKIE['permissions'] > 1)	
	die("需要admin權限！");	
require_once("global.php");

if($_GET['action']=="save")
{
	$sql="update prov set ";
	for($i=1;$i<=$_POST['count'];$i++){
		 //addslashes($_POST["msg$i"]);
		if(!get_magic_quotes_gpc()){
			$prov=addslashes($_POST["prov$i"]);
			$inter=addslashes($_POST["inter$i"]);
			$local=addslashes($_POST["local$i"]);
		}
		else{ 
			$prov=$_POST["prov$i"];
			$inter=$_POST["inter$i"];
			$local=$_POST["local$i"];			
		}
		//$sql.=" msg$i='$msg',";
	
		//$sql.=" id=id where username='$_COOKIE[username]'";
		$sql="update prov set prov='$prov',inter='$inter',local='$local' where id=$i";
		$query=$db->query($sql);
	
	}
	WriteSuccessMsg("<br><li>修改服務商成功</li>","provider.php");
}	

	$query=$db->query("SELECT * FROM prov ");
	while($row=$db->fetch_array($query)) {
		$rsdb[]=$row;
	}	


	require_once ('provider.htm');
?>
