<?php
	echo $_SERVER['SERVER_ADDR']; 
	phpinfo();
?>
