<?php
define("OK", true);
session_start();
if($_SESSION['goip_permissions'] > 1 && $_SESSION['goip_permissions'] < 4)
        die("Permission denied!");
require_once("global.php");
//require_once("sqlsend.php");
//$action="main";
$action=$_REQUEST['action'];
$name=myaddslashes($_REQUEST['name']);
$id=myaddslashes($_REQUEST['id']);
//print_r($_POST);
//die;
if($action=="del")
{
	$ErrMsg="";
	if(empty($id))
		$ErrMsg ='<br><li>Please choose one</li>';
	if($ErrMsg!="")
		WriteErrMsg($ErrMsg);
	else{
		$db->query("DELETE FROM recharge_group where id='$id'");
		$db->query("update goip set re_group_id='0',re_type='0'where re_group_id='$id'");
/*
		$query=$db->query("select sim_team_id from sim_team where auto_simulation_id='$id'");
		while($row=$db->fetch_array($query)) {
			$send[]=my_pack2('LCSCLL', $checksum, SCH_UPDATE, $row[sim_team_id], 0, 0, 0); //nend update scheduler
		}
*/
		//$db->query("update device_line set auto_simulation_id='0',next_auto_dial_time='0' where auto_simulation_id='$id'");
		//$send[]=pack('La*', $checksum, "auto_update");
		//sendto_xchanged($send);
		WriteSuccessMsg("<br><li>Delete successful</li>","?");
	}
}
elseif($action=="saveadd")
{
	$ErrMsg="";
	if(empty($name))        
		$ErrMsg ='<br><li>please input name</li>';
	$no_t=$db->fetch_array($db->query("select id from recharge_group where name='$name'"));
	if($no_t[0])            
		$ErrMsg .='<br><li>This name already exist: '.$name.'</li>';
	if($ErrMsg!="")         
		WriteErrMsg($ErrMsg);
	else{     
		$db->query("insert into recharge_group set name='$name',type='$_POST[type]',default_count='$_POST[default_count]',num_plan='$_POST[num_plan]',num='$_POST[num]',content='$_POST[content]',return_num='$_POST[return_num]',ok_content='$_POST[ok_content]',fail_content='$_POST[fail_content]',num_bre='$_POST[num_bre]',num_aft='$_POST[num_aft]',fixed_num='$_POST[fixed_num]',dynamic_num='$_POST[dynamic_num]'");
		//$send[]=pack('La*', $checksum, "auto_update");
		//sendto_xchanged($send);
		WriteSuccessMsg("<br><li>Add Success</li>","?");
	}
}
else if($action=='savemodify'){
	if(!$id)
		$ErrMsg .='<br><li>please choose one</li>';
        if(empty($name))
                $ErrMsg .='<br><li>please input name</li>';
	$type=$_REQUEST['type'];
        $no_t=$db->fetch_array($db->query("select id from recharge_group where name='$name'and id!='$id'"));
        if($no_t[0])
                $ErrMsg .='<br><li>This name already exist: '.$name.'</li>';
	if($ErrMsg!=""){
		WriteErrMsg($ErrMsg);
		die;
	}

	$db->query("update recharge_group set name='$name',type='$_POST[type]',default_count='$_POST[default_count]',num_plan='$_POST[num_plan]',num='$_POST[num]',content='$_POST[content]',return_num='$_POST[return_num]',ok_content='$_POST[ok_content]',fail_content='$_POST[fail_content]',num_bre='$_POST[num_bre]',num_aft='$_POST[num_aft]',fixed_num='$_POST[fixed_num]',dynamic_num='$_POST[dynamic_num]' where id='$id'");
	$db->query("update goip set re_limit_count='$_POST[default_count]' where re_group_id='$id'");
	//$sql="update auto_simulation set name='$name', dial_num='$_POST[dial_num]',period_min='$_POST[period_min]', period_max='$_POST[period_max]',talk_time_min='$_POST[talk_time_min]',talk_time_max='$_POST[talk_time_max]',next_time='$_POST[next_time]',disable='$_POST[disable]' where id='$id'";
	//$db->query($sql);                              
	//$send[]=pack('La*', $checksum, "auto_update");
	//sendto_xchanged($send);
	WriteSuccessMsg("<br><li>Save Success</li>","?");
}
else if($action=='modify' || $action=="add"){
	if($$action=="add")
		$rs=$db->fetch_array($db->query("select * from recharge_group where 0"));
	else 
		$rs=$db->fetch_array($db->query("select * from recharge_group where id='$_REQUEST[id]'"));
	//print_r($rs);
	if(!$id) $action="add";
}
else if($action=="grecv"){
                if(empty($_GET['id']))
                        WriteErrMsg("<br><li>plesae choose a human simulation!</li>");
                $id=$_GET[id];
                $query=$db->query("SELECT count(*) AS count FROM device_line");
                $row=$db->fetch_array($query);
                $count=$row['count'];
                $numofpage=ceil($count/$perpage);
                $totlepage=$numofpage;
                if(isset($_GET['page'])) {
                        $page=$_GET['page'];
                } else {
                        $page=1;
                }
                if($numofpage && $page>$numofpage) {
                        $page=$numofpage;
                }
                if($page > 1) {
                        $start_limit=($page - 1)*$perpage;
                } else{
                        $start_limit=0;
                        $page=1;
                }
                $query=$db->query("SELECT id FROM device_line where auto_simulation_id=$id order by id");
                $strs0=array();
                $rcount=0;
                while($row=$db->fetch_array($query)) {
                        $rcount++;
                        $strs0[]=$row['id'];
                }
                //echo $rcount;
                $fenye=showpage2("human.php?action=grecv&id=$id&",$page,$count,$perpage,true,true,"线","myform","boxs");
                //if(_GET)
                $query=$db->query("(select device_line.*,name, 1 as 'in' from device_line left join auto_simulation on auto_simulation.id=device_line.auto_simulation_id where device_line.auto_simulation_id=$id order by line_name ASC limit 99999999)
                                union all
                                (select *,NULL,0 from device_line where auto_simulation_id=0 order by line_name ASC limit 99999999) 
                                union all
                                (select device_line.*,name,2 from device_line left join auto_simulation on auto_simulation.id=device_line.auto_simulation_id where device_line.auto_simulation_id!=0 and device_line.auto_simulation_id!=$id order by line_name ASC limit 99999999)
                                        LIMIT $start_limit,$perpage");
                while($row=$db->fetch_array($query)) {

                        if($row[in]==1){
                                $row['yes']="in";
                        }
                        else if($row[in]==0){
                                $row['yes']="none";
                        }
                        else {
                                $row['yes']="other";
                        }
                        if($row['line_status'] == 0 || $row['line_status'] == 12){
                                $row['alive']="OFFLINE";
                        }
                        elseif($row['line_status'] == 11){
                                $row['alive']="ONLINE";
                        }
                        elseif($row['line_status'] == 20){
                                $row['alive']="IDLE";
                        }
                        elseif($row['line_status'] == 21){
                                $row['alive']="BUSY";
                        }
/*
                        elseif($row['line_status'] == 13){
                                $row['alive']="IDLE";
                        }
                        elseif($row['line_status'] == 14){
                                $row['alive']="BUSY";
                        }
*/
                        //else if($row[groupsid]==$id)
                        //if($row['groupsid']==$_GET['id'])
                        $rsdb[]=$row;
                        $strs[]=$row['id'];
                }

                //$strs=array();
                $rsdblen=count($rsdb);
                if(isset($_POST['rstr'])){

                        $nrcount=0;
                        unset($strs0);
                        $strs0=array();
                        if($_POST['rstr']) $strs0=explode(",",$_POST['rstr']);

                        $num=$_POST['boxs'];
                        for($i=0;$i<$num;$i++)
                        {
                                if(!empty($_POST["Id$i"])){
                                        $strs0[]=$_POST["Id$i"];
                                }
                        }

                        //$nrcount=count($strs0);
                        //if(count($strs0)) $strs0=array_unique($strs0);
                        //$strs0=&$strs;

                }
                else {
                        $nrcount=0;
                        $rsdblen=count($rsdb);
                        //print_r();
                        //print_r()
                        //for($i=0;$i<$rsdblen&& $rsdb[$i]['in'];$i++){
                        //unset($strs[$i]);
                        //$str.=$rsdb[$i]['id'].',';
                        ////$strs0[]=$rsdb[$i]['id'];
                        //$nrcount++;
                        //}
                }
                /*
                   for($i=0;$i<$rsdblen&& $rsdb[$i]['in'];$i++){

//$nrcount++;
}
                 */
//echo $nrcount;
foreach($strs0 as $v){
        $nrcount++;
        if(in_array($v,$strs)) continue;
        //$nrcount++;
        $str.=$v.",";

}
//print_r();
$str=substr($str,0,strlen($str)-1);
$nametmp=$db->fetch_array($db->query("SELECT name FROM auto_simulation where id=$_GET[id]"));
$groupsname='<font color="#FF0000">'.$nametmp[0].'</font></a>';
}
elseif($action=="greceivers"){

        if(empty($_GET['id']))
                WriteErrMsg("<br><li>plesae choose a human simulation!</li>");
        $id=$_GET[id];
        $strs=array();
        if($_POST['rstr']) $strs=explode(",",$_POST['rstr']);
        $num=$_POST['boxs'];
        for($i=0;$i<$num;$i++)
        {
                if(!empty($_POST["Id$i"])){
                        $strs[]=$_POST["Id$i"];
                }
        }
        //print_r($strs);
        //$strs=array_unique($strs);

        $query=$db->query("select device_line.*,password from device_line left join rm_device on device_line.goip_name = rm_device.name where auto_simulation_id=$id");

        while($row=$db->fetch_array($query)) {
                $flag=0;
                foreach($strs as $rkey => $rvalue){
                        if($row[0]==$rvalue){
                                unset($strs[$rkey]); //不用insert了；
                                $flag=1;
                                break;
                        }
                        //else $insertstr.=$row[0].",";
                }
                if(!$flag) {
                        $delstrs.=$row[0].","; //数据库有，post没有，需要删除
                        //$row[goip_team_id]=0;
                        //$send[]=my_pack($row, GOIP_ADD);
                }
                //else $insertstr.=$row[0].",";
        }
        if($delstrs){
                $delstrs=substr($delstrs,0,strlen($delstrs)-1);
                //WriteSuccessMsg("delete from receiver where id in ($delstrs)","groups.php?action=recv&id=$id");
                //echo "update goip set goip_team_id=0 where goipid in ($delstrs)";
                $db->query("update device_line set auto_simulation_id=0,next_auto_dial_time='0' where id in ($delstrs)");
        }
        if(count($strs)){
                //echo "111111";
                //$sql="insert into recvgroup values ";
                foreach($strs as $rkey => $rgid){
                        //$sql.="(NULL,$id,$rgid),";
                        $insertstr.=$rgid.",";

                }
                $insertstr=substr($insertstr,0,strlen($insertstr)-1);
                //WriteSuccessMsg($sql,"groups.php?action=recv&id=$id");
                //echo "update goip set goip_team_id=$id where goipid in ($insertstr)";
                $db->query("update device_line set auto_simulation_id=$id where id in ($insertstr)");
        }
        //if($send)
                //sendto_xchanged($send);
        WriteSuccessMsg("<br><li>Successfully Modified</li>","?action=grecv&id=$id");

}
 else {
	$action='main';
	$query=$db->query("SELECT count(*) AS count FROM recharge_group");
        $row=$db->fetch_array($query);
        $count=$row['count'];
        $numofpage=ceil($count/$perpage);
        $totlepage=$numofpage;
        if(isset($_GET['page'])) {
                $page=$_GET['page'];
        } else {
                $page=1;
        }
        if($numofpage && $page>$numofpage) {
                $page=$numofpage;
        }
        if($page > 1) {
                $start_limit=($page - 1)*$perpage;
        } else{
                $start_limit=0;
                $page=1;
        }
        $fenye=showpage("?",$page,$count,$perpage,true,true,"项");
        $query=$db->query("SELECT * FROM recharge_group order by name LIMIT $start_limit,$perpage");
            
	while($row=$db->fetch_array($query)){
		$row['period']=$row['period_min']."-".$row['period_max'];
		$row['talk_time']=$row['talk_time_min']."-".$row['talk_time_max'];
		if($row['disable']) $row['enable']='N';
		else $row['enable']='Y';
		$channel_on_c=0; $channel_all_c=0;
		$query1=$db->query("select gsm_status, count(*) as c from goip where re_group_id=$row[id] and re_type=0 group by gsm_status"); 
		while($row1=$db->fetch_array($query1)){
                        if($row1['gsm_status']=="LOGIN") $channel_on_c+=$row1['c'];
                        $channel_all_c+=$row1['c'];
                }
		$row['be_re_c']=$channel_on_c."/".$channel_all_c;
		$query1=$db->query("select gsm_status, count(*) as c from goip where re_group_id=$row[id] and re_type=1 group by gsm_status"); 
		while($row1=$db->fetch_array($query1)){
                        if($row1['gsm_status']=="LOGIN") $channel_on_c+=$row1['c'];
                        $channel_all_c+=$row1['c'];
                }
		$row['re_c']=$channel_on_c."/".$channel_all_c;
		$row['num_plan']=$row['num_bre'].":".$row['num_aft'];

		$rsdb[]=$row;
	}
}
require_once ('re_group.htm');
?>
